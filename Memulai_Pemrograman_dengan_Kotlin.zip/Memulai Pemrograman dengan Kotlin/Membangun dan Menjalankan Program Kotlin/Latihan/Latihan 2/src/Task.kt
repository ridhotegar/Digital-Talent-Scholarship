fun main() {
    println("Kotlin,")
    println("is Awesome!")
}